import axios from "axios";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react";
import { Form } from "react-bootstrap";
import Navbar from "../components/Navbar";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function editProfile() {
  const [user, setUser] = useState();
  const router = useRouter();
  const defaultFunction = async () => {
    const resp = await axios.post(`/api/getMydata`, {
      username: localStorage.getItem("username"),
    });
    setUser(resp.data[0]);
    // console.log(resp.data[0])
  };

  const handleUsername = () => {
    toast.success("check your mail", {
      theme: "dark",
      autoClose: 3000,
      // style: {fontWeight: "bold",color: "black", border:'1px solid',borderColor: "black blue red pink"}
    });
  };

  const handlechange = (e) => {
    e.preventDefault();
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleEdit = async (e) => {
    e.preventDefault();
    if (user.firstname == "" || /^[ ]*$/.test(user.firstname)) {
      toast.warning("First name is compulsory", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else if (!(/^[a-zA-Z]*$/.test(user.firstname))) {
      toast.warning("First name should be character", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else if (user.lastname == "" || /^[ ]*$/.test(user.lastname)) {
      toast.warning("Last name is compulsory", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else if (!(/^[a-zA-Z]*$/.test(user.lastname))) {
      toast.warning("Last name should be character", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else if (user.email == "" || /^[ ]*$/.test(user.email)) {
      toast.warning("Email is compulsory", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(user.email))) {
      toast.warning("write email in proper formate", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else if (user.phone == "" || /^[ ]*$/.test(user.phone) || !(/^[0-9]*$/.test(user.phone))) {
      toast.warning("write numeric value in phone number", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else if (!(user.phone.length == 10)) {
      toast.warning("Phone number should be of 10 digit", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else if (user.gender == "") {
      toast.warning("select your gender", {
        theme: "dark",
        autoClose: 2000
      });
    }
    else{
      const resp = await axios.post('/api/editProfile',{User:user});
      alert(resp.data);
      router.push('/Profile/'+ localStorage.getItem('username'));
    }
  };

  useEffect(() => {
    defaultFunction();
  }, []);

  return (
    <>
      <div>
        <Navbar />
      </div>
      {user && (
        <div className="d-flex justify-content-center">
          <div style={{ width: "120vh", padding: "5vh" }}>
            <div
              className="border bg-light"
              style={{ borderRadius: "10px", marginTop: "4vh" }}
            >
              <Form style={{ margin: "2rem" }}>
                <div className="d-flex ">
                  <Form.Group
                    className="col-sm-6 mb-3 p-1"
                    controlId="formUsername"
                  >
                    <label
                      for="Username"
                      className="form-label fw-bold"
                      onClick={() => handleUsername()}
                    >
                      Username
                    </label>

                    <Form.Control
                      type="text"
                      placeholder="Enter Username"
                      disabled
                      name="username"
                      defaultValue={user.username}
                      onChange={handlechange}
                    ></Form.Control>
                  </Form.Group>

                  <Form.Group
                    className="col-sm-6 mb-3 p-1"
                    controlId="formFirstname"
                  >
                    <label for="Firstname" className="form-label fw-bold">
                      first Name
                    </label>
                    <Form.Control
                      type="text"
                      placeholder="Enter First name"
                      name="firstname"
                      defaultValue={user.firstname}
                      required
                      onChange={handlechange}
                    ></Form.Control>
                  </Form.Group>
                </div>

                <div className="d-flex ">
                  <Form.Group
                    className="col-sm-6 mb-3 p-1"
                    controlId="formLname"
                  >
                    <label for="Lastname" className="form-label fw-bold">
                      Last Name
                    </label>
                    <Form.Control
                      type="text"
                      placeholder="Enter last name"
                      name="lastname"
                      defaultValue={user.lastname}
                      required
                      onChange={handlechange}
                    ></Form.Control>
                  </Form.Group>
                  <Form.Group
                    className="col-sm-6 mb-3 p-1"
                    controlId="formEmail"
                  >
                    <label for="Email" className="form-label fw-bold">
                      Email
                    </label>
                    <Form.Control
                      type="text"
                      placeholder="Enter Email"
                      name="email"
                      defaultValue={user.email}
                      // required
                      onChange={handlechange}
                    ></Form.Control>
                  </Form.Group>
                </div>

                <div className="d-flex ">
                  <Form.Group
                    className="col-sm-6 mb-3 p-1"
                    controlId="formPhone"
                  >
                    <label for="contact" className="form-label fw-bold">
                      Phone Number
                    </label>
                    <Form.Control
                      type="tel"
                      placeholder="Enter phone number"
                      name="phone"
                      // required
                      defaultValue={user.phone}
                      onChange={handlechange}
                    ></Form.Control>
                  </Form.Group>

                  <form className="col-sm-6 mb-3 p-1" controlId="formGender">
                    <label for="Gender" className="form-label fw-bold">
                      gender
                    </label>
                    <br></br>
                    {/* <Form.Control> */}
                    <input
                      type="radio"
                      name="gender"
                      value="male"
                      defaultChecked={user.gender.includes("male")}
                      // value={user.address}
                      onChange={handlechange}
                      onClick={handlechange}
                    ></input>
                    <label
                      for="male"
                      className="form-label fw-bold"
                      style={{ marginLeft: "1vh", marginRight: "1vh" }}
                    >
                      male
                    </label>
                    <input
                      type="radio"
                      name="gender"
                      value="female"
                      defaultChecked={user.gender.includes("female")}
                      // value={user.address}
                      onChange={handlechange}
                      onClick={handlechange}
                    ></input>
                    <label
                      for="female"
                      className="form-label fw-bold"
                      style={{ marginLeft: "1vh", marginRight: "1vh" }}
                    >
                      female
                    </label>
                    {/* </Form.Control> */}
                  </form>
                </div>

                <div className="text-center">
                  <button className="btn btn-success m-1" onClick={handleEdit}>
                    Edit
                  </button>
                  <br></br>
                  {/* <button className="btn btn-success m-1" onClick={handleEdit}>Edit</button><br></br> */}
                  <span style={{ fontSize: "13px" }}>
                    To change username click on username
                  </span>
                </div>
              </Form>
            </div>
          </div>
        </div>
      )}
      <ToastContainer />
    </>
  );
}
