import '@/styles/globals.css'
import "bootstrap/dist/css/bootstrap.min.css";
import '@/styles/Profile.css';
import '@/styles/Home.css';
import '@/styles/Addpost.css';
import '@/styles/following.css';
export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
