import React, { useEffect, useState } from "react";
// import style from '@/styles/Profile.module.css';
import Head from "next/head";
import { useRouter } from "next/router";
import axios from "axios";
import { FaRegComment, FaShareAlt } from "react-icons/Fa";
import { CiEdit } from "react-icons/Ci";
import { TiTick } from "react-icons/ti";
import { RWebShare } from "react-web-share";
import Dropdown from "react-bootstrap/Dropdown";
import DropdownButton from "react-bootstrap/DropdownButton";
import Navbar from "../components/Navbar";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Profile = () => {
  const router = useRouter();
  const [userdata, setUserdata] = useState();
  const [mypost, setMypost] = useState();
  const [flag, setFlag] = useState();
  const defaultFunction = async () => {
    const resp = await axios.post("/api/myposts", {
      username: localStorage.getItem("username"),
    });
    // console.log("hello" , resp.data.result=="");
    if (resp.data.result == "") {
      setFlag(true);
      setMypost(resp.data.result);
    } else {
      setFlag(false);
      setMypost(resp.data.result);
    }
    setUserdata(resp.data.result1[0]);
  };
  const handleLike = async (id, userid) => {
    try {
      const resp = await axios.post("/api/like", {
        postid: id,
        username: userid,
        fanid: router.query.profile,
      });
      // console.log(resp.data[0].flag);

      if (resp.data[0].flag == 1) {
        document.getElementById(
          id
        ).innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-heart-fill" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"/>
          </svg>`;
      } else {
        document.getElementById(
          id
        ).innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-heart" viewBox="0 0 16 16">
            <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
        </svg>`;
      }
      defaultFunction();
    } catch (err) {
      console.log(err);
    }
  };

  const handleEditProfile = () => {
    document.getElementById("editImage").style.visibility = "visible";
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData(e.target);
    await axios.post("/api/editProfilePhoto", data, {
      headers: {
        id: userdata.id,
      },
    });
    document.getElementById("editImage").style.visibility = "hidden";
    defaultFunction();
  };
  const deletePost = async (id) => {
    const result = confirm("are you sure you want to delete post");
    if (result) {
      const resp = await axios.post("/api/deletePost", { ID: id });
      toast.error(resp.data, {
        theme: "dark",
        autoclose: 1500,
      });
      defaultFunction();
    }
  };
  const handleEdit = (id) => {
    console.log(id);
  };

  const archivePost = async (id) => {
    const result = confirm("are you sure you want to archive post");
    if (result) {
      const resp = await axios.post("/api/archivePost", { ID: id });
      toast.warning(resp.data, {
        theme: "dark",
        autoclose: 1500,
      });
    }
    defaultFunction();
  };
  useEffect(() => {
    defaultFunction();
  }, []);

  return (
    <div>
      <header>
        <Navbar />
      </header>
      <div
        style={{
          backgroundImage:
            "linear-gradient(to right,rgb(120, 146, 219),rgb(216, 115, 199),rgba(53, 53, 218, 0.76),rgb(216, 115, 199))",
          height: "0.5vh",
        }}
      ></div>
      <div>
        <div>
          <Head>
            <title>Profile </title>
            {/* <meta name="viewport" content="width=device-width, initial-scale=1" /> */}
            <meta
              name="viewport"
              content="width=device-width, initial-scale=1.0"
            ></meta>
          </Head>
        </div>

        {userdata && (
          <div className="profile">
            <div id="editImage" style={{ visibility: "hidden", margin: "2vh" }}>
              <form onSubmit={handleSubmit}>
                <label for="img">change profile</label>
                <input className="form-control" type="file" name="img"></input>
                <button
                  title="edit profile"
                  className="btn btn-success"
                  type="submit"
                >
                  <TiTick />
                </button>
              </form>
            </div>
            <div>
              <img title="profile" src={"/images/" + userdata.profile}></img>
              <button
                onClick={() => handleEditProfile()}
                className="btn btn-success button"
                title="Edit Profile"
              >
                <CiEdit />
              </button>
            </div>
            <div>
              <table>
                <thead>
                  <tr>
                    <td className="heading">Username</td>
                    <td> : </td>
                    <td className="data">{userdata.username}</td>
                    <td className="heading">Name</td>
                    <td> : </td>
                    <td className="data">
                      {userdata.firstname} {userdata.lastname}
                    </td>
                  </tr>
                  <tr>
                    <td className="heading">Gender</td>
                    <td> : </td>
                    <td className="data">{userdata.gender}</td>
                    <td className="heading">Phone</td>
                    <td> : </td>
                    <td className="data">{userdata.phone}</td>
                  </tr>
                  <tr>
                    <td className="heading">
                      <button
                        title="click to see followers"
                        onClick={() => {
                          router.push(
                            "../othersFollowers/" +
                              localStorage.getItem("username")
                          );
                        }}
                      >
                        Followers
                      </button>
                    </td>
                    <td> : </td>
                    <td className="data">{userdata.followers}</td>
                    <td className="heading">
                      <button
                        title="click to see following"
                        onClick={() => {
                          router.push(
                            "../othersFollowing/" +
                              localStorage.getItem("username")
                          );
                        }}
                      >
                        Following
                      </button>
                    </td>
                    <td>:</td>
                    <td className="data">{userdata.following}</td>
                  </tr>
                  <tr>
                    <td className="heading">Email</td>
                    <td> : </td>
                    <td className="data">{userdata.email}</td>
                    <td className="heading"></td>
                    <td></td>
                    <td className="data"></td>
                  </tr>
                </thead>
              </table>
            </div>
            <div title="menu bar">
              <DropdownButton
                id="dropdown-basic-button"
                variant="success"
                title="Menu"
              >
                <Dropdown.Item
                  onClick={() => {
                    router.push("../editProfile/" + router.query.profile);
                  }}
                  style={{ marginLeft: "5px" }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-pencil-square"
                    viewBox="0 0 16 16"
                  >
                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                    <path
                      fill-rule="evenodd"
                      d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"
                    />
                  </svg>
                  &nbsp;Edit Profile
                </Dropdown.Item>
                <Dropdown.Item href="../AddPost" style={{ marginLeft: "1vh" }}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-plus-square"
                    viewBox="0 0 16 16"
                  >
                    <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                    <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                  </svg>
                  &nbsp;Add Post
                </Dropdown.Item>
                <Dropdown.Item
                  style={{ textAlign: "center" }}
                  title="archive post"
                  onClick={() => {
                    router.push("../archivePost/" + router.query.profile);
                  }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-archive"
                    viewBox="0 0 16 16"
                  >
                    <path d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z" />
                  </svg>
                  &nbsp;Archived post
                </Dropdown.Item>
                <Dropdown.Divider />
                <Dropdown.Item
                  onClick={() => {
                    router.push("../Body/" + localStorage.getItem("username"));
                  }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-house-heart"
                    viewBox="0 0 16 16"
                  >
                    <path d="M8 6.982C9.664 5.309 13.825 8.236 8 12 2.175 8.236 6.336 5.309 8 6.982Z" />
                    <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.707L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5V8.207l.646.646a.5.5 0 0 0 .708-.707L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5ZM13 7.207V13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V7.207l5-5 5 5Z" />
                  </svg>
                  &nbsp;Home
                </Dropdown.Item>
              </DropdownButton>
            </div>
          </div>
        )}
        {flag ? (
          <>
            <h2 className="text-center mt-5">Not posted anything yet</h2>
          </>
        ) : (
          <>
            <div className="allPost">
              {mypost &&
                mypost.map((items) => (
                  <>
                    <div className="frame">
                      <div className="username d-flex">
                        <div style={{ right: "0" }}>
                          <DropdownButton
                            // id="dropdown-basic-button"
                            title=""
                            variant=""
                            style={{
                              border: "transparent",
                              backgroundColor: "transparent",
                            }}
                          >
                            <Dropdown.Item
                              title="Delete post"
                              onClick={() => deletePost(items.id)}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-trash3"
                                viewBox="0 0 16 16"
                              >
                                <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5ZM11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H2.506a.58.58 0 0 0-.01 0H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1h-.995a.59.59 0 0 0-.01 0H11Zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5h9.916Zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47ZM8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5Z" />
                              </svg>
                              &nbsp;Delete
                            </Dropdown.Item>
                            <Dropdown.Item
                              onClick={() => handleEdit(items.id)}
                              title="Edit post"
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-pencil-square"
                                viewBox="0 0 16 16"
                              >
                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                <path
                                  fill-rule="evenodd"
                                  d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"
                                />
                              </svg>
                              &nbsp;Edit
                            </Dropdown.Item>
                            <Dropdown.Item
                              title="archive post"
                              onClick={() => archivePost(items.id)}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-archive"
                                viewBox="0 0 16 16"
                              >
                                <path d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z" />
                              </svg>
                              &nbsp;Archive
                            </Dropdown.Item>
                          </DropdownButton>
                        </div>
                        <div style={{ marginTop: "0.9vh" }}>
                          &nbsp;{items.userid}
                        </div>
                      </div>
                      <div className="img1">
                        <img
                          className="img"
                          src={"/images/" + items.post}
                        ></img>
                      </div>
                      <div className="like_comment">
                        <button
                          className="btn"
                          id={items.id}
                          onClick={() => handleLike(items.id, items.userid)}
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            fill="currentColor"
                            className="bi bi-heart"
                            viewBox="0 0 16 16"
                          >
                            <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                          </svg>
                        </button>
                        <span style={{ marginTop: "1vh", marginLeft: "-1vh" }}>
                          {items.likes}
                        </span>
                        {/* IoMdHeartEmpty */}
                        {/* FcLike */}
                        <button className="btn">
                          <FaRegComment />
                        </button>
                        <span style={{ marginTop: "1vh", marginLeft: "-1vh" }}>
                          {items.comments}
                        </span>
                        <RWebShare
                          data={{
                            text: "Web Share - GfG",
                            url: "http://localhost:3000",
                            title: "GfG",
                          }}
                          onClick={() => console.log("shared successfully!")}
                        >
                          <button className="btn">
                            <FaShareAlt />
                          </button>
                        </RWebShare>
                      </div>
                      <div>&nbsp;&nbsp;{items.caption}</div>
                    </div>
                  </>
                ))}
            </div>
          </>
        )}
      </div>
      <ToastContainer />
    </div>
  );
};

export default Profile;
