import React, { useEffect, useState } from "react";

import { useRouter } from "next/router";
import { FaRegComment, FaShareAlt } from "react-icons/Fa";
import { RWebShare } from "react-web-share";
import axios from "axios";
import Head from "next/head";
import Navbar from "../components/Navbar";

export default function Body() {
  const [allPost, setAllPost] = useState();
  const router = useRouter();
  const handleLike = async (id, userid) => {
    const resp = await axios.post("/api/like", {
      postid: id,
      username: userid,
      fanid: localStorage.getItem("username"),
    });
    console.log(document.getElementById(id).innerHTML);
    if (resp.data[0].flag == 1) {
      document.getElementById(
        id
      ).innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"/>
          </svg>`;
    } else {
      document.getElementById(
        id
      ).innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart" viewBox="0 0 16 16">
            <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
        </svg>`;
    }
    defaultFunction();
  };

  const defaultFunction = async () => {
    const resp = await axios.post("/api/getAllPost", {
      username: localStorage.getItem("username"),
    });
    // setAllPost(shuffle(resp.data));
    setAllPost(resp.data);
  };

  useEffect(() => {
    defaultFunction();
  }, []);
  return (
    <>
      <Head>
        <title>Home page</title>
      </Head>
      <header>
        <Navbar />
      </header>
    
      <main>
        <div className="d-flex justify-content-center BodyDesign">
          <div className="allPost" style={{ borderRadius: "15px" }}>
            {allPost &&
              allPost.map((items) => (
                <div className="frame">
                  <div className="username">&nbsp;@{items.userid}</div>
                  <div className="img1">
                    <img className="img" src={"/images/" + items.post}></img>
                  </div>
                  <div className="like_comment">
                    <button
                    className="btn"
                      style={{border: "transparent"}}
                      id={items.id}
                      onClick={() => handleLike(items.id, items.userid)}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        class="bi bi-heart"
                        viewBox="0 0 16 16"
                      >
                        <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                      </svg>
                    </button>
                    <span style={{marginTop: "1vh", marginLeft: "-1vh"}}>
                    {items.likes}
                    </span>
                    <button className="btn" style={{border: "transparent"}}>
                      <FaRegComment />
                    </button>
                    <span style={{marginTop: "1vh", marginLeft: "-1vh"}}>
                    {items.comments}
                    </span>
                    <RWebShare
                      data={{
                        text: "Web Share - GfG",
                        url: "http://localhost:3000",
                        title: "GfG",
                      }}
                      onClick={() => console.log("shared successfully!")}
                    >
                      <button className="btn" style={{border: "transparent"}}>
                        <FaShareAlt />
                      </button>

                    </RWebShare>
                  </div>
                  <div>&nbsp;&nbsp;{items.caption}</div>
                </div>
              ))}
          </div>
        </div>
      </main>
    </>
  );
}
