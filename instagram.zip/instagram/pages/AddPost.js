import axios from "axios";
import Router, { useRouter } from "next/router";
import React from "react";
import Navbar from "./components/Navbar";

export default function AddPost() {
  const router = useRouter();
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // console.log("hello");
      const data = new FormData(e.target);
      await axios.post("/api/AddPost", data, {
        headers: { username: localStorage.getItem("username") },
      });
      alert("data added");
      router.push("./Profile/" + localStorage.getItem("username"));
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <>
      <div>
        <Navbar />
      </div>
      <div
        className="text-center fw-bold"
        style={{
          marginTop: "4vh",
          fontSize: "5vh",
          textShadow: "0.5vh 0.5vh 1vh white",
        }}
      >
        Add Post
      </div>
      <div className="AddPost">
        <div className="form_">
          <form
            onSubmit={(e) => {
              handleSubmit(e);
            }}
          >
            {/* <label for= "location">Location</label>
                    <input type="txt" name="location" className='form-control col-md-4'></input> */}
            <div className="form-group col-md-8">
              <label for="img">Add Post</label>
              <input type="file" className="form-control" name="img"></input>
            </div>
            <div className="form-group col-md-8">
              <lable for="caption">caption</lable>
              <input tye="text" className="form-control" name="caption"></input>
            </div>
            <div className="text-center">
              <button
                type="submit"
                className="btn btn-success m-3"
                style={{ boxShadow: "1vh 1vh 1vh black" }}
              >
                Add
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
