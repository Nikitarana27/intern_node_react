import mysql from "mysql";

var con = mysql.createConnection({
  host: "192.168.2.8",
  user: "trainee",
  password: "trainee@123",
  database: "traineedb",
});
export default con;

// create table nikita_user_35
// (
//   id int auto_increment primary key,
//   username varchar(255) not null,
//   password varchar(255),
//   firstname varchar(255),
//   lastname varchar(255),
//   gender varchar(255),
//   email varchar(255),
//   active varchar(255),
//   phone int,
//   dateofenter varchar(255),
//   dateofupdate varchar(255),
//   dateofdelete varchar(255)
// )

// insert into nikita_user_35 (id, username, password, firstname, lastname, gender, email, active, phone, dateofenter, dateofupdate, dateofdelete) values ();

// create table nikita_posts_35(
//   id int auto_increment primary key,
//   post varchar(255),
//   userid varchar(255),
//   likes int,
//   comments int()
// )

// insert into nikita_posts_35 (id, post, userid, likes, comments,caption) values
// ("","img1.jpg","nikita_rana",0,0,"hello their"),
// ("","img2.jpg","nikita_rana",0,0,"i am here"),
// ("","img3.jpg","nikita_rana",0,0,"how are you"),
// ("","img3.jpg","nikita_rana",0,0,"good morning"),
// ("","img4.jpg","nikita_rana",0,0,"vibing"),
// ("","img5.jpg","priya_modi_",0,0,"good night friends"),
// ("","img6.jpg","priya_modi_",0,0,"i am here"),
// ("","img7.jpg","priya_modi_",0,0,"no caption needed"),
// ("","img8.jpg","priya_modi_",0,0,"#girls");

// create table nikita_likes_35
// (
//   id int auto_increment primary key,
//   flag int,
//   fanid varchar(255),
//   userid varchar(255),
//   postid int
// )

// create table nikita_follow_35 (
//   id int auto_increment primary key,
//   flag int,
//   fanid varchar(255),
//   userid varchar(255)
// );
