import con from "../connection/connection";

export default function Login(req, res) {
  con.query(
    `select username,password,email from nikita_user_35 where active = "yes";`,
    (err, result) => {
      if (err) throw err;
      let count = 0;
      for (let i = 0; i < result.length; i++) {
        if (
          result[i].username == req.body.data.username ||
          result[i].email == req.body.data.username
        ) {
          if (result[i].password == req.body.data.password) {
            res.send("welcome");
            break;
          } else {
            res.send("invalid password");
          }
        } else {
          count++;
        }
      }
      if (count == result.length) {
        res.send("invalid user");
      }
    }
  );
}
