import con from "../connection/connection";

export default function getfollowers(req, res) {
  // con.query(`select * from nikita_follow_35 where fanid = "${req.body.userid}"`,(err,result)=>{
  //     if(err) throw err;
  //     res.send(result);
  // });
  con.query(
    `select n.userid as userid from nikita_follow_35 n inner join nikita_follow_35 n1 on n.userid = n1.userid where n.fanid="${req.body.userid}" and n1.fanid = "${req.body.fanid}";`,
    (err, result) => {
      if (err) throw err;

      con.query(
        `select distinct n.userid as userid from nikita_follow_35 n inner join nikita_follow_35 n1 on n.userid != n1.userid where n.fanid="${req.body.userid}" and n1.fanid = "${req.body.fanid}" and n.userid not in (select n.userid as userid from nikita_follow_35 n inner join nikita_follow_35 n1 on n.userid = n1.userid where n.fanid="${req.body.userid}" and n1.fanid = "${req.body.fanid}");`,
        (err, result1) => {
          if (err) throw err;
          res.send({ result, result1 });
        }
      );
    }
  );
}

// select n.userid as userid from nikita_follow_35 n
// inner join nikita_follow_35 n1 on n.userid = n1.userid where n.fanid="${req.body.userid}" and n1.fanid = "${req.body.fanid}";

// select distinct n.userid as userid from nikita_follow_35 n
//     inner join nikita_follow_35 n1 on n.userid != n1.userid where n.fanid="${req.body.userid}" and n1.fanid = "${req.body.fanid}"
//      and n.userid not in (select n.userid as userid from nikita_follow_35 n
// inner join nikita_follow_35 n1 on n.userid = n1.userid where n.fanid="${req.body.userid}" and n1.fanid = "${req.body.fanid}");
