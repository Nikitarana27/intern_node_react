import con from "../connection/connection";

export default async function like(req, res) {
  con.query(
    `select * from nikita_likes_35 where userid = "${req.body.username}" and postid=${req.body.postid} and fanid = "${req.body.fanid}";`,
    (err, result1) => {
      if (err) throw err;
      console.log(
        `select * from nikita_likes_35 where userid = "${req.body.username}" and postid=${req.body.postid} and fanid = "${req.body.fanid}"`
      );
      // console.log(result1[0].flag);
      if (result1 == "") {
        con.query(
          `insert into nikita_likes_35 (id, flag, fanid, userid, postid) values("",1,"${req.body.fanid}","${req.body.username}",${req.body.postid});`,
          (err, result) => {
            if (err) throw err;
          }
        );
        con.query(
          `update nikita_posts_35 set likes = (likes+1) where id = ${req.body.postid}`,
          (err, result) => {
            if (err) throw err;
            con.query(
              `select * from nikita_likes_35 where userid = "${req.body.username}" and postid = ${req.body.postid} and fanid= "${req.body.fanid}"; `,
              (err, resultpost) => {
                if (err) throw err;
                res.send(resultpost);
              }
            );
          }
        );
      } else if (result1[0].flag == 0) {
        con.query(
          `update nikita_likes_35 set flag = 1 where id = ${result1[0].id};`,
          (err, result) => {
            if (err) throw err;
            con.query(
              `update nikita_posts_35 set likes = (likes+1) where id = ${req.body.postid}`,
              (err, result) => {
                if (err) throw err;
                con.query(
                  `select * from nikita_likes_35 where userid = "${req.body.username}" and postid = ${req.body.postid} and fanid= "${req.body.fanid}"; `,
                  (err, resultpost) => {
                    if (err) throw err;
                    res.send(resultpost);
                  }
                );
              }
            );
          }
        );
      } else if (result1[0].flag == 1) {
        con.query(
          `update nikita_likes_35 set flag = 0 where id = ${result1[0].id};`,
          (err, result) => {
            if (err) throw err;
          }
        );
        con.query(
          `update nikita_posts_35 set likes = (likes-1) where id = ${req.body.postid};`,
          (err, result) => {
            if (err) throw err;
            con.query(
              `select * from nikita_likes_35 where userid = "${req.body.username}" and postid = ${req.body.postid} and fanid= "${req.body.fanid}"; `,
              (err, resultpost) => {
                if (err) throw err;
                res.send(resultpost);
              }
            );
          }
        );
      }
    }
  );
}
