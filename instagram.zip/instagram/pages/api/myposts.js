import con from "../connection/connection";

export default function myposts(req, res) {
  con.query(
    `select * from nikita_posts_35 where userid = "${req.body.username}" and flag = 1 order by id desc;`,
    (err, result) => {
      if (err) throw err;
      con.query(
        `select * from nikita_user_35 where username = "${req.body.username}";`,
        (err, result1) => {
          if (err) throw err;
            res.status(200).send({ result, result1 });
        }
      );
    }
  );
}
