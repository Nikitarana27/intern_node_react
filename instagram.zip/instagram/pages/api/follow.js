import con from "../connection/connection";

export default function follow(req, res) {
  // console.log(req.body)
  con.query(
    `select * from nikita_follow_35 where fanid = "${req.body.fanid}" and userid = "${req.body.userid}";`,
    (err, result) => {
      if (err) throw err;
      if (result == "") {
        con.query(
          `update nikita_user_35 set followers=(followers+1) where username = "${req.body.userid}";`,
          (err, result) => {
            if (err) throw err;
          }
        );
        con.query(
          `update nikita_user_35 set following=(following+1) where username = "${req.body.fanid}";`,
          (err, result) => {
            if (err) throw err;
          }
        );
        con.query(
          `insert into nikita_follow_35 (id, fanid, userid) values ('',"${req.body.fanid}","${req.body.userid}")`,
          (err, result) => {
            if (err) throw err;
            res.send("1");
          }
        );
      } else {
        con.query(
          `update nikita_user_35 set followers=(followers-1) where username = "${req.body.userid}";`,
          (err, result) => {
            if (err) throw err;
          }
        );
        con.query(
          `update nikita_user_35 set following=(following-1) where username = "${req.body.fanid}";`,
          (err, result) => {
            if (err) throw err;
          }
        );
        con.query(
          `delete from nikita_follow_35 where fanid = "${req.body.fanid}" and userid = "${req.body.userid}";`,
          (err, result) => {
            if (err) throw err;
            res.send("0");
          }
        );
      }
    }
  );
}
