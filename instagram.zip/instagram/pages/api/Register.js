import con from "../connection/connection.js";
// import formidable from 'formidable';
// import mv from 'mv';

export default function Register(req, res) {
  con.query(`select username from nikita_user_35;`, (err, result) => {
    if (err) throw err;
    let count = 0;
    for (let i = 0; i < result.length; i++) {
      if (result[i].username == req.body.data.username) {
        res.send("username is taken please choose another one");
        break;
      } else {
        count++;
      }
    }
    if (count == result.length) {
      con.query(
        `insert into nikita_user_35 (id, username, password, firstname, lastname, gender, email, active, phone, dateofenter, dateofupdate, dateofdelete, profile, following, followers) values ("","${req.body.data.username}","${req.body.data.password}","${req.body.data.fname}","${req.body.data.lname}","${req.body.data.gender}","${req.body.data.email}","yes","${req.body.data.phone}",concat(curdate()," ",curtime()),concat(curdate()," ",curtime()),"","noprofile.png",0,0);`,
        (err, result) => {
          if (err) throw err;
          res.send("user registered");
        }
      );
    }
  });
}
