import con from "../connection/connection";

export default function editProfile(req, res) {
    console.log(req.body);
  con.query(
    `update nikita_user_35 set firstname = "${req.body.User.firstname}",lastname = "${req.body.User.lastname}" , gender="${req.body.User.gender}",phone = ${req.body.User.phone},email="${req.body.User.email}" where username = "${req.body.User.username}";`,
    (err, result) => {
        if(err) throw err;
        res.status(200).send("user updated");
    }
  );
}
