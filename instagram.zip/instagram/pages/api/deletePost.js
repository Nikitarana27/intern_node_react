import con from "../connection/connection";

export default function deletePost(req,res) {
    con.query(`delete from nikita_posts_35 where id = ${req.body.ID}`,(err,result)=>{
        if(err) throw err;
        con.query(`delete from nikita_likes_35 where postid=${req.body.ID} `,(err,result)=>{
            if(err) throw err;
            res.send("Post Deleted")
        })
    })
}