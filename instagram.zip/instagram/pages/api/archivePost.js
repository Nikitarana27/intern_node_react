import con from "../connection/connection";

export default function archivePost(req,res){
    con.query(`update nikita_posts_35 set flag = 0 where id = ${req.body.ID};`,(err,result)=>{
        if(err) throw err;
        res.status(200).send('post archieved');
    })
}