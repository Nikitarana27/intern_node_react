import con from "../connection/connection";

export default function getAllPost(req, res) {
  con.query(
    `select * from nikita_posts_35 where flag = 1 order by id desc;`,
    (err, result) => {
      if (err) throw err;
      res.send(result);
    }
  );
}
