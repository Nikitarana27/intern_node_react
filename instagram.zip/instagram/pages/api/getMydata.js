import con from "../connection/connection";

export default function getMydata(req,res){
    con.query(
        `select * from nikita_user_35 where username = "${req.body.username}";`,
        (err, result) => {
          if (err) throw err;
            res.status(200).send(result);
        }
      );
}