import con from "../connection/connection";

export default function getArchivePost(req, res) {
  con.query(
    `select * from nikita_posts_35 where userid= "${req.body.username}" and flag = 0;`,
    (err, result) => {
      if (err) throw err;
      res.status(200).send(result);
    }
  );
}
