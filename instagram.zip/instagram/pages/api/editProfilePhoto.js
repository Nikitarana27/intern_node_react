import con from "../connection/Connection";
import formidable from "formidable";
import mv from "mv";

export const config = {
  api: {
    bodyParser: false,
  },
};

export default function editProfile(req, res) {
  // console.log("hello");
  // console.log(req.headers['id']);
  const form = new formidable.IncomingForm();
  form.parse(req, function (err, fields, files) {
    // console.log(files);
    var oldPath = files.img.filepath;
    var newPath = `./public/Images/${files.img.originalFilename}`;
    mv(oldPath, newPath, function (err) {});
    con.query(
      `update nikita_user_35 set profile = "${files.img.originalFilename}" where id = ${req.headers["id"]}`,
      (err, result) => {
        if (err) throw err;
        res.send("okay");
      }
    );
  });
}
