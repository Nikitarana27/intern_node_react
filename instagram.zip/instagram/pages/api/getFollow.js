import con from "../connection/connection";

export default function (req, res) {
  con.query(
    `select * from nikita_follow_35 where fanid = "${req.body.fanid}" and userid = "${req.body.userid}";`,
    (err, result) => {
      if (err) throw err;
      if (result == "") {
        res.send("0");
      } else {
        res.send("1");
      }
    }
  );
}
