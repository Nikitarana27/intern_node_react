import con from "../connection/connection";

export default function suggestion(req, res) {
  con.query(
    `select distinct userid from nikita_follow_35 where (fanid in (select userid from nikita_follow_35 where fanid = "${req.body.username}")) and (userid not in (select userid from nikita_follow_35 where fanid = "${req.body.username}")) and userid != "${req.body.username}";`,
    (err, result) => {
        if(err) throw err;
        if(result==""){
            res.status(200).send("no data");
        }
        else{
            res.status(200).send(result);
        }
    }
  );
}
