import con from "../connection/connection";
export default function checkSearch(req, res) {
  con.query(
    `select * from nikita_user_35 where active = "yes";`,
    (err, result) => {
      if (err) throw err;
      let count = 0;
      for (let i = 0; i < result.length; i++) {
        if (result[i].username != req.body.Search) {
          count++;
        }
      }
      if (count == result.length) {
        res.send("user not exist");
      } else {
        res.send("okay");
      }
    }
  );
}
