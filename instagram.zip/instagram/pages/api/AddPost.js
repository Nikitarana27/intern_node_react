import con from "../connection/connection";
import formidable from "formidable";
import mv from "mv";
export const config = {
  api: {
    bodyParser: false,
  },
};

export default function AddPost(req, res) {
  // console.log("hello");
  const form = new formidable.IncomingForm();
  form.parse(req, (err, fields, files) => {
    // console.log(err);
    // console.log(files.img.originalFilename);
    if (
      files.img.originalFilename == "" ||
      files.img.originalFilename == "undefined"
    ) {
      res.send("insert image properly..");
    } else if (files.img.originalFilename == req.headers["img"]) {
      res.send("same image is selected...");
    } else {
      var oldPath = files.img.filepath;
      var newPath = `./public/images/${files.img.originalFilename}`;
      mv(oldPath, newPath, function (err) {});
      con.query(
        `insert into nikita_posts_35 (id, post, userid, likes, comments, caption,flag) values ("","${files.img.originalFilename}","${req.headers["username"]}",0,0,"${fields.caption}",1)`,
        (err, result) => {
          if (err) throw err;
          res.send("okay");
        }
      );
    }
  });
}
