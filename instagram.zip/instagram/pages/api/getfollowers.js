import con from "../connection/connection";

export default function getfollowers(req, res) {
  con.query(
    `select n.fanid as fanid from nikita_follow_35 n inner join nikita_follow_35 n1 on n.fanid = n1.userid where n.userid="${req.body.userid}" and n1.fanid = "${req.body.fanid}";`,
    (err, result) => {
      if (err) throw err;

      con.query(
        `select distinct n.fanid as fanid from nikita_follow_35 n inner join nikita_follow_35 n1 on n.fanid != n1.userid where n.userid="${req.body.userid}" and n1.fanid = "${req.body.fanid}" and n.fanid not in (select n.fanid from nikita_follow_35 n inner join nikita_follow_35 n1 on n.fanid = n1.userid where n.userid="${req.body.userid}" and n1.fanid = "${req.body.fanid}");`,
        (err, result1) => {
          if (err) throw err;
          res.send({ result, result1 });
        }
      );
    }
  );
  // con.query(`select * from nikita_follow_35 where userid = "${req.body.userid}"`,(err,result)=>{
  //     if(err) throw err;

  // con.query(`select * from nikita_follow_35 where fanid = "${req.body.fanid}"`,(err,result1)=>{
  //     if(err) throw err;
  //     res.send({result, result1});
  // })
  // });
}
