import axios from "axios";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react";
import Dropdown from "react-bootstrap/Dropdown";
import DropdownButton from "react-bootstrap/DropdownButton";
import { FaRegComment, FaShareAlt } from "react-icons/Fa";
import { RWebShare } from "react-web-share";
import Navbar from "../components/Navbar";

export default function archivePost() {
  const [archivePost, setArchivePost] = useState();
  const router = useRouter();

  const defaultFunction = async () => {
    const resp = await axios.post(`/api/getArchivePost`, {
      username: router.query.archivePost,
    });
    setArchivePost(resp.data);
  };

  const deletePost = () => {};

  const unArchiveAllPost =async () => {
    const resp = await axios.post('/api/unarchive',{username: router.query.archivePost,flag: 0});
    router.push("../archivePost/"+localStorage.getItem('username'));
  };

  const UnarchivePost = () => {};

  useEffect(() => {
    defaultFunction();
  }, []);

  return (
    <>
      <div>
        <Navbar />
      </div>
      <div>
        {archivePost !="" ? (
          <>
            <div className="allPost">
              {archivePost && archivePost.map((items) => {
                return (
                  <>
                    <div className="frame">
                      <div className="username d-flex">
                        <div>
                          <DropdownButton
                            // id="dropdown-basic-button"
                            title=""
                            variant=""
                            style={{
                              border: "transparent",
                              backgroundColor: "transparent",
                            }}
                          >
                            <Dropdown.Item
                              title="Delete post"
                              onClick={() => deletePost(items.id)}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-trash3"
                                viewBox="0 0 16 16"
                              >
                                <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5ZM11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H2.506a.58.58 0 0 0-.01 0H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1h-.995a.59.59 0 0 0-.01 0H11Zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5h9.916Zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47ZM8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5Z" />
                              </svg>
                              &nbsp;Delete
                            </Dropdown.Item>
                            <Dropdown.Item
                              onClick={() => unArchiveAllPost(items.id)}
                              title="Archive all post"
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-archive-fill"
                                viewBox="0 0 16 16"
                              >
                                <path d="M12.643 15C13.979 15 15 13.845 15 12.5V5H1v7.5C1 13.845 2.021 15 3.357 15h9.286zM5.5 7h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1zM.8 1a.8.8 0 0 0-.8.8V3a.8.8 0 0 0 .8.8h14.4A.8.8 0 0 0 16 3V1.8a.8.8 0 0 0-.8-.8H.8z" />
                              </svg>
                              &nbsp;archive All
                            </Dropdown.Item>
                            <Dropdown.Item
                              title="Unarchive post"
                              onClick={() => UnarchivePost(items.id)}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                fill="currentColor"
                                class="bi bi-archive"
                                viewBox="0 0 16 16"
                              >
                                <path d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z" />
                              </svg>
                              &nbsp;Unarchive
                            </Dropdown.Item>
                          </DropdownButton>
                        </div>
                        <div style={{ marginTop: "0.9vh" }}>
                          &nbsp;{items.userid}
                        </div>
                      </div>
                      <div className="img1">
                        <img
                          className="img"
                          src={"/images/" + items.post}
                        ></img>
                      </div>
                      <div className="like_comment">
                        <button
                          className="btn"
                          id={items.id}
                          // onClick={() => handleLike(items.id, items.userid)}
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            fill="currentColor"
                            className="bi bi-heart"
                            viewBox="0 0 16 16"
                          >
                            <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                          </svg>
                        </button>
                        <span style={{ marginTop: "1vh", marginLeft: "-1vh" }}>
                          {items.likes}
                        </span>
                        {/* IoMdHeartEmpty */}
                        {/* FcLike */}
                        <button className="btn">
                          <FaRegComment />
                        </button>
                        <span style={{ marginTop: "1vh", marginLeft: "-1vh" }}>
                          {items.comments}
                        </span>
                        <RWebShare
                          data={{
                            text: "Web Share - GfG",
                            url: "http://localhost:3000",
                            title: "GfG",
                          }}
                          onClick={() => console.log("shared successfully!")}
                        >
                          <button className="btn">
                            <FaShareAlt />
                          </button>
                        </RWebShare>
                      </div>
                      <div>&nbsp;&nbsp;{items.caption}</div>
                    </div>
                  </>
                );
              })}
            </div>
          </>
        ) : (
          <>
            <h2 className="text-center m-5">you don't have any archived post</h2>
          </>
        )}
      </div>
    </>
  );
}
