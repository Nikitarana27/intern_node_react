import React, { useEffect, useState } from "react";
// import style from '@/styles/Profile.module.css';
import Head from "next/head";
import { useRouter } from "next/router";
import axios from "axios";
import { FaRegComment, FaShareAlt } from "react-icons/Fa";
import { CiEdit } from "react-icons/Ci";
import { TiTick } from "react-icons/ti";
import { RWebShare } from "react-web-share";
import Dropdown from "react-bootstrap/Dropdown";
import DropdownButton from "react-bootstrap/DropdownButton";

const Profile = () => {
  const router = useRouter();
  const [userdata, setUserdata] = useState();
  const [mypost, setMypost] = useState();

  const defaultFunction = async () => {
    const resp = await axios.post("/api/myposts", {
      username: router.query.viewProfile,
    });
    // console.log(resp.data.result1);
    setMypost(resp.data.result);
    setUserdata(resp.data.result1[0]);
    const resp1 = await axios.post("/api/getFollow", {
      userid: router.query.viewProfile,
      fanid: localStorage.getItem("username"),
    });
    if (resp1.data == "0") {
      document.getElementById("follow").style.visibility = "visible";
      document.getElementById("following").style.visibility = "hidden";
    } else {
      document.getElementById("following").style.visibility = "visible";
      document.getElementById("follow").style.visibility = "hidden";
    }
  };
  const handleLike = async (id, userid) => {
    const resp = await axios.post("/api/like", {
      postid: id,
      username: userid,
      fanid: router.query.viewProfile,
    });
    // console.log(resp.data[0].flag);

    if (resp.data[0].flag == 1) {
      document.getElementById(
        id
      ).innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-heart-fill" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"/>
          </svg>`;
    } else {
      document.getElementById(
        id
      ).innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-heart" viewBox="0 0 16 16">
            <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
        </svg>`;
    }
    defaultFunction();
  };

  const handleFollow = async () => {
    if (router.query.viewProfile == localStorage.getItem("username")) {
      alert("you can't follow yourself");
    } else {
      const resp = await axios.post("/api/follow", {
        userid: router.query.viewProfile,
        fanid: localStorage.getItem("username"),
      });
      defaultFunction();
    }
  };

  useEffect(() => {
    defaultFunction();
  }, []);

  return (
    <div>
      <div>
        <Head>
          <title>Profile </title>
          {/* <meta name="viewport" content="width=device-width, initial-scale=1" /> */}
          <meta
            name="viewport"
            content="width=device-width, initial-scale=1.0"
          ></meta>
        </Head>
      </div>
      {mypost && (
        <>
          {userdata && (
            <div className="profile">
              <div>
                <img src={"/images/" + userdata.profile}></img>
              </div>
              <div>
                <table>
                  <thead>
                    <tr>
                      <td className="heading">Username</td>
                      <td> : </td>
                      <td className="data">{userdata.username}</td>
                      <td className="heading">Name</td>
                      <td> : </td>
                      <td className="data">
                        {userdata.firstname} {userdata.lastname}
                      </td>
                    </tr>
                    <tr>
                      <td className="heading">Gender</td>
                      <td> : </td>
                      <td className="data">{userdata.gender}</td>
                      <td className="heading">Email</td>
                      <td> : </td>
                      <td className="data">{userdata.email}</td>
                    </tr>
                    <tr>
                      <td className="heading">
                        <button
                          onClick={() => {
                            router.push(
                              "../othersFollowers/" + router.query.viewProfile
                            );
                          }}
                        >
                          Followers
                        </button>
                      </td>
                      <td> : </td>
                      <td className="data">{userdata.followers}</td>
                      <td className="heading">
                        <button
                          onClick={() => {
                            router.push(
                              "../othersFollowing/" + router.query.viewProfile
                            );
                          }}
                        >
                          Following
                        </button>
                      </td>
                      <td>:</td>
                      <td className="data">{userdata.following}</td>
                    </tr>
                  </thead>
                </table>
                <div className="follow">
                  <button
                    id="follow"
                    className="btn btn-primary"
                    onClick={handleFollow}
                  >
                    Follow
                  </button>
                  <button
                    id="following"
                    className="btn btn-primary"
                    onClick={handleFollow}
                  >
                    Following
                  </button>
                </div>
              </div>
              <div>
                <DropdownButton id="dropdown-basic-button" title="">
                <Dropdown.Item
                  onClick={() => {
                    router.push("../Body/" + localStorage.getItem("username"));
                  }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-house-heart"
                    viewBox="0 0 16 16"
                  >
                    <path d="M8 6.982C9.664 5.309 13.825 8.236 8 12 2.175 8.236 6.336 5.309 8 6.982Z" />
                    <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.707L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5V8.207l.646.646a.5.5 0 0 0 .708-.707L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5ZM13 7.207V13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V7.207l5-5 5 5Z" />
                  </svg>
                  &nbsp;Home
                </Dropdown.Item>
                </DropdownButton>
              </div>
            </div>
          )}
          <div className="allPost">
            {mypost.map((items) => (
              <>
                <div className="frame">
                  <div className="username">&nbsp;{items.userid}</div>
                  <div className="img1">
                    <img className="img" src={"/images/" + items.post}></img>
                  </div>
                  <div className="like_comment">
                    <button
                      className="btn"
                      id={items.id}
                      onClick={() => handleLike(items.id, items.userid)}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        className="bi bi-heart"
                        viewBox="0 0 16 16"
                      >
                        <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                      </svg>
                    </button>
                    {items.likes}
                    {/* IoMdHeartEmpty */}
                    {/* FcLike */}
                    <button className="btn">
                      <FaRegComment /> {items.comments}
                    </button>
                    <RWebShare
                      data={{
                        text: "Web Share - GfG",
                        url: "http://localhost:3000",
                        title: "GfG",
                      }}
                      onClick={() => console.log("shared successfully!")}
                    >
                      <button className="btn">
                        <FaShareAlt />
                      </button>
                    </RWebShare>
                  </div>
                  <div>&nbsp;&nbsp;{items.caption}</div>
                </div>
              </>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default Profile;
