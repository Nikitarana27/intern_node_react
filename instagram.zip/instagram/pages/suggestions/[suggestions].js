import axios from "axios";
import { useRouter } from "next/router";
import React, { useEffect } from "react";
import { useState } from "react";
import Navbar from "../components/Navbar";

export default function suggestions() {
  const router = useRouter();
  const [suggestedFollowers, setSuggestedFollowers] = useState();
  const defaultFunction = async () => {
    const resp = await axios.post("/api/suggestion", {
      username: localStorage.getItem("username"),
    });
    if(resp.data == "no data"){
      alert("no suggestion available");
      router.push('../Profile/'+localStorage.getItem('username'));
    }
    else{
      setSuggestedFollowers(resp.data);
    }
    // const resp = await axios.post('/api/suggestion',{username : Router.query.suggestions});
  }

  const handleFollow = async (userid_) => {
    const resp = await axios.post("/api/follow", {
      userid: userid_,
      fanid: localStorage.getItem("username"),
    });
    defaultFunction();
  };

  useEffect(()=>{
    defaultFunction();
  },[])

  return (
    <div>
      <div>
        <Navbar />
      </div>
      <div className="d-flex justify-content-center m-5">
        <div className="followers">
          {suggestedFollowers &&
            suggestedFollowers.map((items) => {
              return (
                <>
                  <div className="text-center followers1 mb-1">
                    <div>{items.userid}</div>
                    <div className="text-right">
                      <button
                        id="handlebutton"
                        className="btn btn-primary btn-sm"
                        onClick={() => {
                          handleFollow(items.userid);
                        }}
                      >
                        follow
                      </button>
                    </div>
                  </div>
                </>
              );
            })}
        </div>
      </div>
    </div>
  );
}

// select userid from nikita_follow_35 where (fanid in (select userid from nikita_follow_35 where fanid = "nikita_rana")) and (userid not in (select userid from nikita_follow_35 where fanid = "nikita_rana")) and userid != "nikita_rana";
