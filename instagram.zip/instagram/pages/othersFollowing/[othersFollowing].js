import axios from "axios";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react";
import Navbar from "../components/Navbar";

export default function followers() {
  const [common, setcommon] = useState();
  const [others, setothers] = useState();
  const router = useRouter();
  const defaultFunction = async () => {
    try {
      const res = await axios.post("/api/getfollowing", {
        userid: router.query.othersFollowing,
        fanid: localStorage.getItem("username"),
      });
      setcommon(res.data.result);
      setothers(res.data.result1);
    } catch (err) {
      console.log(err);
    }
  };

  const handleFollow = async (userid_) => {
    try {
      const resp = await axios.post("/api/follow", {
        userid: userid_,
        fanid: localStorage.getItem("username"),
      });
      defaultFunction();
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    defaultFunction();
  }, []);

  return (
    <>
      <div>
        <Navbar />
      </div>
      <div className="d-flex justify-content-center m-5">
        <div className="followers">
          {common &&
            common.map((items) => {
              return (
                <>
                  <div className="text-center followers1 mb-1">
                    <div>{items.userid}</div>
                    <div className="text-right">
                      <button
                        id="handlebutton"
                        className="btn btn-primary btn-sm"
                        onClick={() => {
                          handleFollow(items.userid);
                        }}
                      >
                        following
                      </button>
                    </div>
                  </div>
                </>
              );
            })}
          {others &&
            others.map((items) => {
              return (
                <>
                  <div className="text-center followers1 mb-1">
                    <div>{items.userid}</div>
                    <div className="text-right">
                      {items.userid == localStorage.getItem("username") ? (
                        "you"
                      ) : (
                        <button
                          id="handlebutton"
                          className="btn btn-primary btn-sm"
                          onClick={() => {
                            handleFollow(items.userid);
                          }}
                        >
                          follow
                        </button>
                      )}
                    </div>
                  </div>
                </>
              );
            })}
        </div>
      </div>
    </>
  );
}
